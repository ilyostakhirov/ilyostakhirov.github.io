$('#card').inputmask({"mask": "8600 9999 9999 9999"});

$('#phone').inputmask({"mask": "99 999 99 99"});
$('#code').inputmask({"mask": "999999"});